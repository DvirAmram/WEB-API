﻿using DivChatWEBAPI.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DivChatWEBAPI.Controllers
{
    [Route("api/contacts/{contactname}/[controller]")]
    [ApiController]
    public class messagesController : ControllerBase
    {
        private IUserDataService service;
        public messagesController()
        {
            service = new UserDataService();
        }
        // GET: api/<messagesController>
        [HttpGet]
        public IActionResult Get(string connecteduser, string contactname)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null) return NotFound();
            List<message> messages = user.chats.Where(x => x.contact.id == contactname).FirstOrDefault().messages;

            return Ok(messages);
        }

        // GET api/<messagesController>/5
        [HttpGet("{id}")]
        public IActionResult Get(string connecteduser, string contactname,int id)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null) return NotFound();
            List<message> messages = user.chats.Where(x => x.contact.id == contactname).FirstOrDefault().messages;
            message mess = messages.Where(x => x.id == id).FirstOrDefault();
            if (mess == null) return NotFound();
            return Ok(mess);
        }

        // POST api/<messagesController>
        [HttpPost]
        public IActionResult Post(string connecteduser, string contactname, string content)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null) return NotFound();
            List<message> messages = user.chats.Where(x => x.contact.id == contactname).FirstOrDefault().messages;
            int id;
            if (messages.Count == 0)
            {
                id = 0;
            }
            else
            {
                id = messages.Max(x => x.id) + 1;
            }
            messages.Add(new message() { id = id, content = content, created = DateTime.Now, sent = true });
            return StatusCode(201);       
        }

        // PUT api/<messagesController>/5
        [HttpPut("{id}")]
        public IActionResult Put(string connecteduser,string contactname, int id, string content)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null) return NotFound();
            List<message> messages = user.chats.Where(x => x.contact.id == contactname).FirstOrDefault().messages;
            message mess = messages.Where(x => x.id == id).FirstOrDefault();
            if (mess == null) return NotFound();
            mess.content = content;
            return NoContent();
        }

        // DELETE api/<messagesController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(string connecteduser, string contactname, int id)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null) return NotFound();
            List<message> messages = user.chats.Where(x => x.contact.id == contactname).FirstOrDefault().messages;
            message mess = messages.Where(x => x.id == id).FirstOrDefault();
            if (mess == null) return NotFound();
            messages.Remove(mess);
            return NoContent();
        }
    }
}
