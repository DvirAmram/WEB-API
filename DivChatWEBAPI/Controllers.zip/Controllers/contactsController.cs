﻿using DivChatWEBAPI.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DivChatWEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class contactsController : ControllerBase
    {
        private IUserDataService service;
        public contactsController()
        {
            service = new UserDataService();
        }
        // GET: api/<ContactsController>
        [HttpGet]
        public IActionResult Get(string connecteduser)
        {
            //User user = service.Get(UserDataService.connected);

            User user = service.Get(connecteduser);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user.chats.Select(o => o.contact));
        }

        // GET api/<ContactsController>/5
        [HttpGet("{id}")]
        public IActionResult Get(string connecteduser,string id)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null)
            {
                return NotFound();
            }
            contact contact = user.chats.Select(o => o.contact).Where(x => x.id == id).FirstOrDefault();
            if (contact == null)
            {
                return NotFound();
            }
            return Ok(contact);
        }

        // POST api/<ContactsController>
        [HttpPost]
        public IActionResult Post(string connecteduser, string id,string name, string server)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null)
            {
                return NotFound();
            }
            contact contact = user.chats.Select(o => o.contact).Where(x => x.id == id && x.server == server).FirstOrDefault();
            if (contact == null)
            {
                user.chats.Add(new Chat() {contact = new contact()
                {
                    id = id,
                    name = name,
                    server = server,
                    last = null,
                    lastdate = null
                },messages = new List <message>()});
                return StatusCode(201);
            }
            else
                return NotFound();
        }

        // PUT api/<ContactsController>/5
        [HttpPut("{id}")]
        public IActionResult Put(string connecteduser, string id, string name, string server)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null)
            {
                return NotFound();
            }
            contact contact = user.chats.Select(o => o.contact).Where(x => x.id == id).FirstOrDefault();
            if (contact == null)
            {
                return NotFound();
            }
            else
            {
                contact.name = name;
                contact.server = server;
                return NoContent();
            }
        }

        // DELETE api/<ContactsController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(string connecteduser,string id)
        {
            //User user = service.Get(UserDataService.connected);
            User user = service.Get(connecteduser);
            if (user == null)
            {
                return NotFound();
            }
            contact contact = user.chats.Select(o => o.contact).Where(x => x.id == id).FirstOrDefault();
            if (contact == null)
            {
                return NotFound();
            }
            else
            {
                user.chats.Remove(user.chats.Where(x => contact == x.contact).FirstOrDefault());
                return NoContent();
            }
        }

        //// GET api/<ContactsController>/{id}/5
        ////[Route("api/[controller]/{id}/messages")]
        //[HttpGet("{id}")]
        //public IActionResult Get(string id)
        //{
        //    User user = service.Get(UserDataService.connected);
        //    if (user == null)
        //    {
        //        return NotFound();
        //    }
        //    Contact contact = user.contacts.Where(x => x.id == id).FirstOrDefault();
        //    if (contact == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(contact);
        //}
    }
}
