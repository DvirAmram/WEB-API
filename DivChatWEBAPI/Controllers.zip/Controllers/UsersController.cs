﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DivChatWEBAPI.Models;

namespace DivChatWEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private IUserDataService service;

        public UsersController()
        {
            service = new UserDataService();
        }

        // GET: api/Users
        [HttpGet]
        public IActionResult GetUser()
        {
            return Ok(service.GetAll());
        }

        // GET: api/Users/5
        //[HttpGet("{id}")]
        //public async Task<ActionResult<User>> GetUser(string id)
        //{

        //}

        // PUT: api/Users/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutUser(string id, User user)
        //{
        //    if (id != user.Username)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(user).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!UserExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}
        //GET: api/Users/5
        //[HttpGet("GetChat/{id}")]
        //public IActionResult GetChat(string connecteduser, string contactid)
        //{
        //    User user = service.GetAll().Where(o => o.Username == connecteduser).FirstOrDefault();
        //    if (user == null)
        //    {
        //        return NotFound();
        //    }
        //}
        // POST: api/Users
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        // create new user = register
        [HttpPost]
        public IActionResult signUp(User user)
        {
            if (service.GetAll().Select(o => o.Username).Contains(user.Username))
            {
                return BadRequest();
            }
            service.Create(user);
            return NoContent();
        }

        [HttpPost("login/{user_name}/{password}")]
        public IActionResult login(string user_name, string password)
        {
            User user = service.GetAll().Where(o => o.Username == user_name).FirstOrDefault();
            if (user == null)
            {
                return NotFound();
            }
            if (user.Password != password)
            {
                return NotFound();
            }
            return Ok(user);
        }

        // DELETE: api/Users/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteUser(string id)
        //{
        //    var user = await _context.User.FindAsync(id);
        //    if (user == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.User.Remove(user);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        //private bool UserExists(string id)
        //{
        //    return _context.User.Any(e => e.Username == id);
        //}
    }
}
