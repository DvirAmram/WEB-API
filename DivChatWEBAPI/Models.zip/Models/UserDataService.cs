﻿namespace DivChatWEBAPI.Models
{
    public class UserDataService : IUserDataService
    {
        private static List<User> users = new List<User>()
        {
            new User(){ Username="bob",
                        Nickname = "boby",
                        Password = "123",
                        SrcImg = "fds",
                        chats = new List<Chat>(){ new Chat(){contact = new contact (){id = "alice",
                                                                      name = "Alicia",
                        server = "locallhost:7266", last = "any last words?", lastdate = new DateTime() } , messages = new List<message>(){new message(){id = 3 , content = "hello" , created = new DateTime(), sent = true} , new message() { id = 5, content = "world", created = new DateTime(), sent = false } }} ,
            new Chat(){contact = new contact (){id = "niv",name = "niven",server = "locallhost:7266", last = "any last words?", lastdate = new DateTime() } , messages = new List<message>(){new message(){id = 3 , content = "yalla" , created = new DateTime(), sent = true} , new message() { id = 5, content = "hapoel", created = new DateTime(), sent = false } }} } },
            
            new User(){ Username="yossi",
                        Nickname = "yoss",
                        Password = "123",
                        SrcImg = "fds",
                        chats = new List<Chat>(){ new Chat(){contact = new contact (){id = "shlomo",
                                                                      name = "hamelech",
                        server = "locallhost:7266", last = "any last words?", lastdate = new DateTime() } , messages = new List<message>(){new message(){id = 3 , content = "hello" , created = new DateTime(), sent = true} , new message() { id = 5, content = "world", created = new DateTime(), sent = false } }} } },
             
            new User(){ Username="Niv",
                        Nickname = "Nickool",
                        Password = "1",
                        SrcImg = "fds",
                        chats = new List<Chat>(){ new Chat(){contact = new contact (){id = "alice",
                                                                      name = "Alicia",
                        server = "locallhost:7266", last = "any last words?", lastdate = new DateTime() } , messages = new List<message>(){new message(){id = 3 , content = "hello" , created = new DateTime(), sent = true} , new message() { id = 5, content = "world", created = new DateTime(), sent = false } }} } },

        };
        //public static string connected = "bob";

        public List<User> GetAll()
        {
            return users;
        }
        public User Get(string id)
        {
            return users.Find(x => x.Username == id);
        }
        public void Create(User user)
        {
            users.Add(user);
        }
        public void Edit(string id, User user)
        {
            User u = Get(id);
            u.Nickname = user.Nickname;
            u.Password = user.Password;
            u.SrcImg = user.SrcImg;
            u.chats = user.chats;
        }

        public void Delete(string id)
        {
            users.Remove(Get(id));
        }

    }
}
